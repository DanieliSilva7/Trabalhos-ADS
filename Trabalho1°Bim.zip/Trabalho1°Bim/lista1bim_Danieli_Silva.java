import java.util.Scanner;

public class lista1bim_Danieli_Silva{

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\nDigite o número do exercício que deseja executar (0 para sair):");
            opcao = sc.nextInt();

            switch(opcao) {
                case 1:
                    exercicio1();
                    break;
                case 2:
                    exercicio2();
                    break;
                case 3:
                    exercicio3();
                    break;
                case 4:
                    exercicio4();
                    break;
                case 5:
                    exercicio5();
                    break;
                case 6:
                    exercicio6();
                    break;
                case 7:
                    exercicio7();
                    break;
                case 8:
                    exercicio8();
                    break;
                case 9:
                    exercicio9();
                    break;
                case 10:
                    exercicio10();
                    break;
                case 11:
                    exercicio11();
                    break;
                case 12:
                    exercicio12();
                    break;
                case 13:
                    exercicio13();
                    break;
                case 14:
                    exercicio14();
                    break;
                case 15:
                    exercicio15();
                    break;

                case 0:
                    System.out.println("Saindo do programa...");
                    break;
                default:
                    System.out.println("Opção inválida! Digite novamente.");
            }

        } while(opcao != 0);

        sc.close();
    }

    public static void exercicio1() {
        System.out.println("Executando Exercício 1...");

        /*Faça um programa que peça dois números inteiros ao usuário. Depois exiba se o primeiro é maior, menor ou igual ao segundo. */

        int num1, num2;
Scanner s = new  Scanner (System.in);

System.out.print ("Informe o primeiro numero:" );
num1 = s.nextInt();

System.out.println("Informe o segundo numero:");
num2 = s.nextInt();

if (num1 > num2) {
            System.out.println("O primeiro número é maior que o segundo!");
        } else if (num1 < num2) {
            System.out.println("O primeiro número é menor que o segundo!");
        } else {
            System.out.println("Os dois números são iguais!");
        }
    }

    public static void exercicio2() {
        System.out.println("Executando Exercício 2...");
        /*Faça um programa que peça um número ao usuário. Exiba se esse número é Par ou Ímpar (use o operador de resto da divisão - mod %).*/

        Scanner s = new Scanner (System.in);
        String resultado="Numero PAR!";
        int num;
        System.out.println("Informe o primeiro numero:");
            num = s.nextInt();

            if (num % 2 != 0) {
                resultado = ("Numero IMPAR!");
            
            }
            System.out.println("Resultado: " + resultado);
            }

    public static void exercicio3() {
        System.out.println("Executando Exercício 3...");
        /*Faça um programa que peça ao usuário o valor do relógio de água de uma residência no dia 1º do mês e no dia 30º do mesmo mês.
        Depois mostre quantos litros foram consumidos e a média por dia. considere 30 dias.*/

            double leitura_relogio_inicial, leitura_relogio_final;
            double media, consumo;
            Scanner s = new Scanner (System.in);

            System.out.print("Informe o valor do relogio de agua no 1 dia: ");
                leitura_relogio_inicial = s.nextDouble();
                System.out.println("Informe o valor do relogio de agua no 30 dia: ");
                leitura_relogio_final = s.nextDouble();


                consumo = leitura_relogio_final - leitura_relogio_inicial;
                media = consumo / 30;

                System.out.println("Litros Consumidos: " + consumo + "\nMedia diaria: " + media);

    }

    public static void exercicio4() {
        System.out.println("Executando Exercício 4...");
        /*Faça um programa que peça ao usuário um número inteiro qualquer. Se ele for maior que 10 e menor que 100, calcule a potência dele elevado a 2.
        Se ele for maior que 100 ou menor que 10, exiba a raiz quadrada do valor. Exiba os valores com 5 casas decimais. */

    Scanner entrada = new Scanner(System.in);
    System.out.print("Digite um número inteiro: ");
    int numero = entrada.nextInt();
    double resultado;

    if (numero > 10 && numero < 100) {
        resultado = Math.pow(numero, 2);
        System.out.println("O número está entre 10 e 100.");
        System.out.printf("Potência: %.5f%n", resultado);

    } else if (numero > 100 || numero < 10) {
        resultado = Math.sqrt(numero);
        System.out.println("O número é maior que 100 ou menor que 10.");
        System.out.printf("Raiz quadrada: %.5f%n", resultado);

    } else {
        System.out.println("O número é igual a 10 ou 100, nenhuma operação será realizada.");
    }

}

    public static void exercicio5() {
        System.out.println("Executando Exercício 5...");
        /*Dado os três valores, A, B e C, verificar se eles podem ser os comprimentos dos lados de um triângulo, se forem, verificar se compõem um triângulo equilátero, isósceles ou escaleno. Dados de Entrada: Três lados de um suposto triângulo A, B e C. Dados de saída: mensagens: não compõem um triângulo, triângulo equilátero, triângulo isósceles, triângulo escaleno. 
É um triângulo?: Figura geométrica fechada de três lados, em que cada um é menor que a soma dos outros dois.
Triângulo equilátero: possui três lados iguais.
Triângulo isósceles: possui dois lados iguais.
Triângulo escaleno: possui todos os lados diferentes.
 */

Scanner s = new Scanner(System.in);

    System.out.print("Informe o valor do lado A: ");
    double a = s.nextDouble();

    System.out.print("Informe o valor do lado B: ");
    double b = s.nextDouble();

    System.out.print("Informe o valor do lado C: ");
    double c = s.nextDouble();

    // Verifica se é possível formar um triângulo
    if (a < b + c && b < a + c && c < a + b) {
        System.out.println("É um triângulo!");

        // Verifica o tipo de triângulo
        if (a == b && b == c) {
            System.out.println("Triângulo Equilátero (três lados iguais)");
        } else if (a == b || a == c || b == c) {
            System.out.println("Triângulo Isósceles (dois lados iguais)");
        } else {
            System.out.println("Triângulo Escaleno (todos os lados diferentes)");
        }
    } else {
        System.out.println("Não compõem um triângulo!");
    }
}

    public static void exercicio6() {
        System.out.println("Executando Exercício 6...");
        /*Tendo como dados de entrada a altura, o peso e o sexo de uma pessoa, construa um algoritmo que calcule seu peso ideal, usando as fórmulas abaixo e
        exiba se a pessoa está abaixo, no peso ou acima do peso ideal.
        homens: (72.7 * H) - 58
        mulheres: (62.1 * H) - 44.7
 */
    
    Scanner s = new Scanner(System.in);

    System.out.print("Informe a altura (em metros): ");
    double altura = s.nextDouble();

    System.out.print("Informe o peso atual (em kg): ");
    double peso = s.nextDouble();

    System.out.print("Informe o sexo (M para masculino, F para feminino): ");
    char sexo = s.next().toUpperCase().charAt(0);

    double pesoIdeal;

    if (sexo == 'M') {
        pesoIdeal = (72.7 * altura) - 58;
    } else if (sexo == 'F') {
        pesoIdeal = (62.1 * altura) - 44.7;
    } else {
        System.out.println("Sexo inválido! Use 'M' para masculino ou 'F' para feminino.");
        return;
    }

    System.out.printf("Peso ideal calculado: %.2f kg%n", pesoIdeal);

    // Comparação do peso atual com o ideal
    if (peso < pesoIdeal - 1) {
        System.out.println("Você está abaixo do peso ideal.");
    } else if (peso > pesoIdeal + 1) {
        System.out.println("Você está acima do peso ideal.");
    } else {
        System.out.println("Você está no peso ideal!");
    }
}

    public static void exercicio7() {
        System.out.println("Executando Exercício 7...");
        /*Faça um algoritmo que leia o ano de nascimento de uma pessoa, calcule e exiba se: ela já tem idade para votar (16 anos ou mais);
        se já tem idade para tirar habilitação (18 anos ou mais) ou se é menor de 16 anos “não pode nem votar nem tirar carteira”. */

    Scanner s = new Scanner(System.in);

    System.out.print("Informe o ano de nascimento: ");
    int anoNascimento = s.nextInt();

    System.out.print("Informe o ano atual: ");
    int anoAtual = s.nextInt();

    int idade = anoAtual - anoNascimento;

    System.out.println("Idade calculada: " + idade + " anos.");

    if (idade >= 18) {
        System.out.println("Pode votar e tirar habilitação!");
    } else if (idade >= 16) {
        System.out.println("Pode votar, mas ainda não pode tirar habilitação.");
    } else {
        System.out.println("Não pode nem votar nem tirar carteira.");
    }
}

    public static void exercicio8() {
        System.out.println("Executando Exercício 8...");
        /*Faça um algoritmo que, dada a idade de um nadador, mostre a qual classificação ele pertence conforme a tabela abaixo:
Idade               Categoria
5 até 7 anos        Infantil A
8 até 10 anos       Infantil B
11 a 13 anos        Juvenil A
14 a 17 anos        Juvenil B
18 ou mais          Adulto*/


    Scanner s = new Scanner(System.in);

    System.out.print("Informe a idade do nadador: ");
    int idade = s.nextInt();

    if (idade < 5) {
        System.out.println("Idade insuficiente para classificação (menor de 5 anos).");
    } else if (idade <= 7) {
        System.out.println("Categoria: Infantil A");
    } else if (idade <= 10) {
        System.out.println("Categoria: Infantil B");
    } else if (idade <= 13) {
        System.out.println("Categoria: Juvenil A");
    } else if (idade <= 17) {
        System.out.println("Categoria: Juvenil B");
    } else {
        System.out.println("Categoria: Adulto");
    }
}
    
    public static void exercicio9() {
        System.out.println("Executando Exercício 9...");
    /*Construa um algoritmo que calcule a soma de números pares que o usuário informar enquanto ele não digitar zero.
      O usuário pode informar qualquer número entre 0 e 100, mas só deve ser somado se ele for par. Encerrar o laço quando o usuário digitar 0. */
    
    System.out.println("Executando Exercício 9...");
    Scanner s = new Scanner(System.in);

    int numero;
    int soma = 0;

    do {
        System.out.print("Informe um número entre 0 e 100 (0 para sair): ");
        numero = s.nextInt();

        if (numero < 0 || numero > 100) {
            System.out.println("Número fora do intervalo permitido! Digite novamente.");
        } else if (numero % 2 == 0 && numero != 0) {
            soma += numero;
        }
    } while (numero != 0);
    System.out.println("A soma dos números pares informados é: " + soma);
}

    public static void exercicio10() {
        System.out.println("Executando Exercício 10...");
        /*Imagine uma brincadeira entre dois colegas onde um fornece um número e o outro deve adivinhar qual é.
        Como dica, indique se o chute dado foi alto ou baixo em relação ao número escolhido. Pode sortear um número aleatório também. (repita)*/
    
    Scanner s = new Scanner(System.in);

    // Sorteia um número aleatório entre 1 e 100
    int numeroSecreto = (int) (Math.random() * 100) + 1;
    int tentativa;

    System.out.println("Tente adivinhar o número (entre 1 e 100)!");

    do {
        System.out.print("Digite seu palpite: ");
        tentativa = s.nextInt();

        if (tentativa > numeroSecreto) {
            System.out.println("Seu chute foi ALTO demais!");
        } else if (tentativa < numeroSecreto) {
            System.out.println("Seu chute foi BAIXO demais!");
        } else {
            System.out.println("Parabéns! Você acertou o número secreto!");
        }

    } while (tentativa != numeroSecreto);
}


    public static void exercicio11() {
        System.out.println("Executando Exercício 11...");
    /*Crie um programa que fique pedindo ao usuário um número qualquer entre 10 e 29. Depois sorteie um número qualquer (Randon) e compare os dois números.
    Caso sejam iguais exiba a mensagem “PARABÉNS! Você acertou!”. Caso contrário, exiba a mensagem “QUE PENA. Não foi desta vez. Tente novamente!”.
    Encerre o laço quando o usuário digitar 9. */

    Scanner s = new Scanner(System.in);

    int numeroUsuario;
    do {
        System.out.print("Digite um número entre 10 e 29 (9 para sair): ");
        numeroUsuario = s.nextInt();

        if (numeroUsuario == 9) {
            System.out.println("Programa encerrado!");
            break;
        }

        if (numeroUsuario < 10 || numeroUsuario > 29) {
            System.out.println("Número inválido! Tente novamente.");
            continue; // pula para a próxima iteração
        }

        int numeroSorteado = (int) (Math.random() * 20) + 10; // gera número aleatório entre 10 e 29
        System.out.println("Número sorteado: " + numeroSorteado);

        if (numeroUsuario == numeroSorteado) {
            System.out.println("PARABÉNS! Você acertou!");
        } else {
            System.out.println("QUE PENA. Não foi desta vez. Tente novamente!");
        }

    } while (numeroUsuario != 9);
    
    }

    public static void exercicio12() {
        System.out.println("Executando Exercício 12...");
        /*Crie um laço de repetição que peça ao usuário 3 números inteiros e se ele deseja ordená-los em ordem crescente ou decrescente.
        Exiba os números conforme a ordem selecionada.  */

    Scanner s = new Scanner(System.in);

    int num1, num2, num3;
    char ordem;

    System.out.print("Informe o primeiro número: ");
    num1 = s.nextInt();
    System.out.print("Informe o segundo número: ");
    num2 = s.nextInt();
    System.out.print("Informe o terceiro número: ");
    num3 = s.nextInt();

    System.out.print("Deseja ordenar em ordem crescente (C) ou decrescente (D)? ");
    ordem = s.next().toUpperCase().charAt(0);

    int temp;

    // Ordenação simples usando ifs
    // Coloca num1 <= num2 <= num3
    if (num1 > num2) { temp = num1; num1 = num2; num2 = temp; }
    if (num2 > num3) { temp = num2; num2 = num3; num3 = temp; }
    if (num1 > num2) { temp = num1; num1 = num2; num2 = temp; }

    if (ordem == 'C') {
        System.out.println("Números em ordem crescente: " + num1 + ", " + num2 + ", " + num3);
    } else if (ordem == 'D') {
        System.out.println("Números em ordem decrescente: " + num3 + ", " + num2 + ", " + num1);
    } else {
        System.out.println("Opção inválida! Use 'C' para crescente ou 'D' para decrescente.");
    }

    }

    public static void exercicio13() {
        System.out.println("Executando Exercício 13...");
        /*Solicite ao usuário uma palavra. Use um laço “for” para percorrer a string e estruturas de decisão (if-else ou switch)
        para contar o número total de vogais (a, e, i, o, u) e o número total de consoantes. Ignore os espaços.
         Exiba o número de vogais e o número de consoantes que a palavra informada possui. . */
        
    Scanner s = new Scanner(System.in);

    System.out.print("Digite uma palavra ou frase: ");
    String palavra = s.nextLine().toLowerCase(); // transforma tudo em minúsculo para facilitar a comparação

    int vogais = 0;
    int consoantes = 0;

    for (int i = 0; i < palavra.length(); i++) {
        char c = palavra.charAt(i);

        if (c >= 'a' && c <= 'z') { // considera apenas letras
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                vogais++;
            } else {
                consoantes++;
            }
        }
    }

    System.out.println("Número de vogais: " + vogais);
    System.out.println("Número de consoantes: " + consoantes);
    }

    public static void exercicio14() {
        System.out.println("Executando Exercício 14...");
        /*Crie um validador de senha que peça ao usuário uma senha a ser verificada, o nome da pessoa, o sobrenome da pessoa e retorne o resultado da avaliação
        da senha (“Atende critérios” ou “Não atende Critérios”). Os critérios são:
        A senha deve conter no mínimo 8 caracteres.
        Pelo menos um dos caracteres deve ser ‘@’ ou ‘!’ ou ‘#’.
        Primeiro caractere da senha não pode ser o primeiro caractere do nome nem do sobrenome.
        Senha não pode conter o nome ou sobrenome inteiro da pessoa.*/

    Scanner s = new Scanner(System.in);

    // Solicita dados do usuário
    System.out.print("Digite seu nome: ");
    String nome = s.nextLine().trim();
    System.out.print("Digite seu sobrenome: ");
    String sobrenome = s.nextLine().trim();
    System.out.print("Digite a senha a ser verificada: ");
    String senha = s.nextLine().trim();

    boolean atende = true; // variável que indica se a senha atende os critérios

    // Critério 1: pelo menos 8 caracteres
    if (senha.length() < 8) {
        atende = false;
        System.out.println("Senha deve ter no mínimo 8 caracteres.");
    }

    // Critério 2: pelo menos um dos caracteres especiais @, !, #
    if (!senha.contains("@") && !senha.contains("!") && !senha.contains("#")) {
        atende = false;
        System.out.println("Senha deve conter pelo menos um dos caracteres especiais: @, ! ou #.");
    }

    // Critério 3: primeiro caractere da senha não pode ser o primeiro caractere do nome nem do sobrenome
    if (senha.charAt(0) == nome.charAt(0) || senha.charAt(0) == sobrenome.charAt(0)) {
        atende = false;
        System.out.println("Primeiro caractere da senha não pode ser o primeiro caractere do nome ou sobrenome.");
    }

    // Critério 4: senha não pode conter o nome ou sobrenome inteiro
    String senhaLower = senha.toLowerCase();
    if (senhaLower.contains(nome.toLowerCase()) || senhaLower.contains(sobrenome.toLowerCase())) {
        atende = false;
        System.out.println("Senha não pode conter o nome ou sobrenome inteiro.");
    }

    // Resultado final
    if (atende) {
        System.out.println("Senha válida: Atende critérios.");
    } else {
        System.out.println("Senha inválida: Não atende critérios.");
    }
    }

    public static void exercicio15() {
        System.out.println("Executando Exercício 15...");
        /*Crie uma função chamada “calculo”, com retorno double e que receba dois parâmetros double (num1 e num2).
        Quando num1 for maior que num2, ela deve retornar a multiplicação dos dois. Quando o num1 for menor que num2, deve-se retornar a divisão entre os dois.
         Quando eles forem iguais, deve-se retornar a soma deles. No final, exiba qual a condição atendida e o resultado do cálculo.  */

    
    Scanner s = new Scanner(System.in);

    System.out.print("Digite o primeiro número: ");
    double num1 = s.nextDouble();

    System.out.print("Digite o segundo número: ");
    double num2 = s.nextDouble();

    double resultado = calculo(num1, num2); // chama a função calculo
}

// Função calculo
public static double calculo(double num1, double num2) {
    double resultado;
    if (num1 > num2) {
        resultado = num1 * num2;
        System.out.println("Condição atendida: num1 > num2 (Multiplicação)");
    } else if (num1 < num2) {
        resultado = num1 / num2;
        System.out.println("Condição atendida: num1 < num2 (Divisão)");
    } else {
        resultado = num1 + num2;
        System.out.println("Condição atendida: num1 == num2 (Soma)");
    }

    System.out.println("Resultado do cálculo: " + resultado);
    return resultado;

    }

}
